// ============================================
// GYMA — ACCOUNT SCREEN
// ============================================
const AccountScreen = (() => {
  function mount(el) {
    el.id = 'screen-account';
    el.className = 'screen active';
    const user = Storage.getUser() || {};
    const initial = (user.name || 'G')[0].toUpperCase();
    const history = Storage.getHistory();

    el.innerHTML = `
      <div style="padding:56px 24px 48px">
        <div style="display:flex;flex-direction:column;align-items:center;margin-bottom:32px">
          <div class="account-avatar" id="avatar-circle">${initial}<div class="avatar-edit-badge">✏️</div></div>
          <div class="account-name">${user.name || 'Athlete'}</div>
          <div style="font-size:14px;color:var(--muted);margin-top:4px">${history.length} workouts completed</div>
        </div>

        <div class="account-section">
          <div class="account-section-title">Profile</div>
          <div class="account-row">
            <span class="account-row-label">Name</span>
            <input type="text" id="acc-name" class="input" style="width:160px;text-align:right" value="${user.name||''}" />
          </div>
          <div class="account-row">
            <span class="account-row-label">Age</span>
            <input type="number" id="acc-age" class="input" style="width:80px;text-align:right" value="${user.age||''}" />
          </div>
          <div class="account-row">
            <span class="account-row-label">Height</span>
            <span class="account-row-val">${user.height || '—'} ${user.units === 'imperial' ? 'ft' : 'cm'}</span>
          </div>
          <div class="account-row">
            <span class="account-row-label">Weight</span>
            <span class="account-row-val">${user.weight || '—'} ${user.units === 'imperial' ? 'lbs' : 'kg'}</span>
          </div>
        </div>

        <div class="account-section">
          <div class="account-section-title">Training</div>
          <div class="account-row">
            <span class="account-row-label">Goal</span>
            <span class="account-row-val">${formatGoal(user.goal)}</span>
          </div>
          <div class="account-row">
            <span class="account-row-label">Level</span>
            <select id="acc-level" class="input" style="width:160px;background:var(--elevated)">
              <option value="beginner" ${user.level==='beginner'?'selected':''}>Beginner 🌱</option>
              <option value="intermediate" ${user.level==='intermediate'?'selected':''}>Intermediate 💪</option>
              <option value="advanced" ${user.level==='advanced'?'selected':''}>Advanced 🔥</option>
            </select>
          </div>
          <div class="account-row">
            <span class="account-row-label">Training Days</span>
            <span class="account-row-val">${(user.freeDays||[]).length} days/week</span>
          </div>
        </div>

        <div class="account-section">
          <div class="account-section-title">Settings</div>
          <div class="account-row">
            <span class="account-row-label">Notifications</span>
            <div class="toggle-switch ${user.notifications ? 'on' : ''}" id="notif-toggle"></div>
          </div>
          <div class="account-row">
            <span class="account-row-label">Camera Permission</span>
            <span class="account-row-val" id="cam-perm-status">Checking...</span>
          </div>
          <div class="account-row">
            <span class="account-row-label">App Version</span>
            <span class="account-row-val">GYMA 1.0</span>
          </div>
        </div>

        <button class="btn btn-primary btn-full" id="acc-save" style="margin-top:28px">Save Changes</button>

        <div class="danger-zone">
          <div class="account-section-title" style="color:var(--error)">Danger Zone</div>
          <button class="btn-danger" id="acc-reset">Reset All App Data</button>
        </div>
      </div>`;

    // Camera perm check
    if (navigator.permissions) {
      navigator.permissions.query({name:'camera'}).then(r => {
        const el2 = document.getElementById('cam-perm-status');
        if (el2) el2.textContent = r.state === 'granted' ? '✅ Granted' : '❌ ' + r.state;
      }).catch(() => {});
    }

    el.querySelector('#notif-toggle').addEventListener('click', function() {
      this.classList.toggle('on');
      const u = Storage.getUser() || {};
      u.notifications = this.classList.contains('on');
      Storage.setUser(u);
    });

    el.querySelector('#acc-save').addEventListener('click', () => {
      const u = Storage.getUser() || {};
      const newName = el.querySelector('#acc-name').value.trim();
      const newAge = el.querySelector('#acc-age').value;
      const newLevel = el.querySelector('#acc-level').value;
      if (newName) u.name = newName;
      if (newAge) u.age = newAge;
      if (newLevel !== u.level) {
        u.level = newLevel;
        // Regenerate plan
        const plan = WorkoutLib.generatePlan(u);
        Storage.setPlan(plan);
        App.toast('Level updated — plan regenerated!', 'success');
      }
      Storage.setUser(u);
      App.toast('Profile saved ✓', 'success');
      // Update avatar initial
      const av = document.getElementById('avatar-circle');
      if (av) av.childNodes[0].textContent = (newName||u.name||'G')[0].toUpperCase();
    });

    el.querySelector('#acc-reset').addEventListener('click', () => {
      if (confirm('This will delete all your data and restart GYMA. Are you sure?')) {
        Storage.clearAll();
        App.navigate('splash');
      }
    });
  }

  function formatGoal(g) {
    const map = { lose_weight:'Lose Weight 🔥', build_muscle:'Build Muscle 💪', stay_active:'Stay Active 🧘', improve_endurance:'Endurance ⚡' };
    return map[g] || g || '—';
  }
  return { mount };
})();
window.AccountScreen = AccountScreen;
