// ============================================
// GYMA — ONBOARDING FLOW (Steps 1–9)
// ============================================

const OnboardingScreen = (() => {
  let currentStep = 0;
  let userData = {
    name: '', age: '', height: '', weight: '',
    units: 'metric', goal: '', level: '',
    freeDays: [], location: '',
  };
  const TOTAL_STEPS = 9;

  const GOALS = [
    { key: 'lose_weight', emoji: '🔥', label: 'Lose Weight' },
    { key: 'build_muscle', emoji: '💪', label: 'Build Muscle' },
    { key: 'stay_active', emoji: '🧘', label: 'Stay Active' },
    { key: 'improve_endurance', emoji: '⚡', label: 'Improve Endurance' },
  ];
  const LEVELS = [
    { key: 'beginner', emoji: '🌱', label: 'Beginner', sub: 'New to training' },
    { key: 'intermediate', emoji: '💪', label: 'Intermediate', sub: '1–2 years experience' },
    { key: 'advanced', emoji: '🔥', label: 'Advanced', sub: '3+ years experience' },
  ];
  const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  function mount(el) {
    el.id = 'screen-onboarding';
    el.className = 'screen active';
    el.innerHTML = `
      <div class="progress-bar-track"><div class="progress-bar-fill" id="ob-progress"></div></div>
      <div id="ob-step-container"></div>`;
    renderStep(el);
  }

  function renderStep(el) {
    const pct = ((currentStep + 1) / TOTAL_STEPS) * 100;
    el.querySelector('#ob-progress').style.width = pct + '%';
    const container = el.querySelector('#ob-step-container');
    container.style.opacity = '0';
    container.style.transform = 'translateY(16px)';
    container.style.transition = 'none';
    requestAnimationFrame(() => {
      container.style.transition = 'opacity 0.35s, transform 0.35s';
      container.style.opacity = '1';
      container.style.transform = 'translateY(0)';
    });

    const stepFns = [step1, step2, step3, step4, step5, step6, step7, step8, step9];
    container.innerHTML = stepFns[currentStep]();
    bindStep(el);
  }

  function advance() {
    if (currentStep < TOTAL_STEPS - 1) {
      currentStep++;
      renderStep(document.getElementById('screen-onboarding'));
    }
  }

  function baseLayout(question, content, showBack = true) {
    return `
      <div class="onboarding-step active" style="padding:56px 24px 32px;min-height:100%;display:flex;flex-direction:column">
        ${showBack && currentStep > 0 ? `<button id="ob-back" style="background:none;border:none;color:var(--muted);font-size:24px;cursor:pointer;align-self:flex-start;padding:0 0 16px 0">←</button>` : '<div style="height:40px"></div>'}
        <h2 class="onboarding-question">${question}</h2>
        ${content}
      </div>`;
  }

  function step1() {
    return baseLayout('What\'s your name?', `
      <input type="text" id="ob-name" class="input input-large" placeholder="First name" autocomplete="given-name" value="${userData.name}" />
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next">Continue →</button></div>`);
  }

  function step2() {
    return baseLayout('How old are you?', `
      <input type="number" id="ob-age" class="input input-large" placeholder="25" min="13" max="99" value="${userData.age}" />
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next">Continue →</button></div>`);
  }

  function step3() {
    return baseLayout("What's your height & weight?", `
      <div class="units-toggle">
        <button id="unit-metric" class="${userData.units === 'metric' ? 'active' : ''}">kg / cm</button>
        <button id="unit-imperial" class="${userData.units === 'imperial' ? 'active' : ''}">lbs / ft</button>
      </div>
      <div style="display:flex;gap:12px">
        <div style="flex:1">
          <label style="font-size:12px;color:var(--muted);display:block;margin-bottom:8px">${userData.units === 'metric' ? 'HEIGHT (cm)' : 'HEIGHT (ft)'}</label>
          <input type="number" id="ob-height" class="input" placeholder="${userData.units === 'metric' ? '175' : '58'}" value="${userData.height}" />
        </div>
        <div style="flex:1">
          <label style="font-size:12px;color:var(--muted);display:block;margin-bottom:8px">${userData.units === 'metric' ? 'WEIGHT (kg)' : 'WEIGHT (lbs)'}</label>
          <input type="number" id="ob-weight" class="input" placeholder="${userData.units === 'metric' ? '75' : '165'}" value="${userData.weight}" />
        </div>
      </div>
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next" style="margin-top:24px">Continue →</button></div>`);
  }

  function step4() {
    const cards = GOALS.map(g => `
      <div class="onboarding-card ${userData.goal === g.key ? 'selected' : ''}" data-goal="${g.key}">
        <span class="card-emoji">${g.emoji}</span>
        <span>${g.label}</span>
      </div>`).join('');
    return baseLayout("What's your fitness goal?", `
      <div class="onboarding-cards">${cards}</div>
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next" style="margin-top:24px" ${!userData.goal ? 'disabled' : ''}>Continue →</button></div>`);
  }

  function step5() {
    const cards = LEVELS.map(l => `
      <div class="onboarding-card ${userData.level === l.key ? 'selected' : ''}" data-level="${l.key}" style="flex-direction:column;align-items:flex-start">
        <div style="display:flex;align-items:center;gap:12px;width:100%">
          <span class="card-emoji">${l.emoji}</span>
          <div>
            <div style="font-size:17px;font-weight:700">${l.label}</div>
            <div style="font-size:13px;color:var(--muted);margin-top:2px">${l.sub}</div>
          </div>
        </div>
      </div>`).join('');
    return baseLayout("What's your fitness level?", `
      <div class="onboarding-cards">${cards}</div>
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next" style="margin-top:24px" ${!userData.level ? 'disabled' : ''}>Continue →</button></div>`);
  }

  function step6() {
    const pills = DAYS.map((d, i) => `
      <div class="day-pill ${userData.freeDays.includes(i) ? 'selected' : ''}" data-day="${i}">${d}</div>`).join('');
    return baseLayout('Which days are you free to train?', `
      <p style="color:var(--muted);font-size:14px;margin:-16px 0 20px">Select at least 2 days</p>
      <div class="day-pills">${pills}</div>
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next" style="margin-top:24px" ${userData.freeDays.length < 2 ? 'disabled' : ''}>Continue →</button></div>`);
  }

  function step7() {
    return baseLayout('Choose your workout location', `
      <div style="display:flex;flex-direction:column;gap:16px;flex:1;justify-content:center;margin-top:16px">
        <div class="onboarding-card ${userData.location === 'home' ? 'selected' : ''}" data-loc="home"
          style="flex-direction:row;align-items:center;text-align:left;padding:24px 20px;gap:20px">
          <div style="width:64px;height:64px;border-radius:50%;background:rgba(232,80,10,0.1);display:flex;align-items:center;justify-content:center;border:1px solid rgba(232,80,10,0.3);flex-shrink:0">
            <span style="font-size:32px">🏠</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:4px">
            <span style="font-size:20px;font-weight:700;font-family:var(--font-display);letter-spacing:1px">At Home</span>
            <span style="font-size:14px;color:var(--muted);font-weight:400">Camera-tracked sessions</span>
          </div>
        </div>
        <div class="onboarding-card" data-loc="gym"
          style="flex-direction:row;align-items:center;text-align:left;padding:24px 20px;gap:20px;position:relative;opacity:0.6">
          <div style="width:64px;height:64px;border-radius:50%;background:var(--bg);display:flex;align-items:center;justify-content:center;border:1px solid var(--border);flex-shrink:0">
            <span style="font-size:32px">🏢</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:4px">
            <span style="font-size:20px;font-weight:700;font-family:var(--font-display);letter-spacing:1px">In Gym</span>
            <span style="font-size:14px;color:var(--muted);font-weight:400">Weight machines & racks</span>
          </div>
          <div class="gym-coming-ribbon" style="top:24px;border-radius:4px">SOON</div>
        </div>
      </div>
      <div class="mt-auto"><button class="btn btn-primary btn-full btn-xl" id="ob-next" style="margin-top:24px" ${!userData.location ? 'disabled' : ''}>Continue →</button></div>`);
  }

  function step8() {
    return baseLayout('Set up permissions', `
      <div class="permission-screen" style="flex:1;padding:0">
        <div class="permission-icon">📷</div>
        <h3 class="permission-title">Camera Access</h3>
        <p class="permission-body">GYMA needs your camera to track your movements in real time and give form feedback.</p>
        <button class="btn btn-primary btn-full btn-xl" id="ob-allow-camera">Allow Camera →</button>
        <p class="permission-body" style="margin-top:12px">
          <span style="font-size:32px">🔔</span><br/>
          Stay on track with workout reminders.
        </p>
        <button class="btn btn-secondary btn-full" id="ob-allow-notif">Allow Notifications →</button>
        <button class="btn btn-ghost btn-full" id="ob-next" style="margin-top:12px">Skip for now</button>
      </div>`, false);
  }

  function step9() {
    const steps = [
      { id: 'ps1', label: 'Analyzing your goal' },
      { id: 'ps2', label: 'Calculating weekly volume' },
      { id: 'ps3', label: 'Scheduling rest days' },
      { id: 'ps4', label: 'Building your plan' },
    ];
    const listHTML = steps.map(s =>
      `<li class="plan-gen-step" id="${s.id}"><span class="step-icon">○</span><span>${s.label}</span></li>`
    ).join('');
    return `
      <div class="plan-generation-screen">
        <div class="plan-gen-title">Building your<br/>personal plan</div>
        <div style="width:100%;height:4px;background:var(--border);border-radius:2px;overflow:hidden;max-width:300px">
          <div id="plan-progress-fill" style="width:0%;height:100%;background:linear-gradient(90deg,var(--orange),var(--orange-soft));border-radius:2px;transition:width 0.4s"></div>
        </div>
        <ul class="plan-gen-steps">${listHTML}</ul>
        <div id="plan-result" style="display:none;width:100%;text-align:left"></div>
      </div>`;
  }

  function bindStep(el) {
    const next = el.querySelector('#ob-next');
    const back = el.querySelector('#ob-back');
    if (back) back.addEventListener('click', () => { if (currentStep > 0) { currentStep--; renderStep(el); } });

    if (currentStep === 0) {
      const inp = el.querySelector('#ob-name');
      if (next) next.addEventListener('click', () => {
        const v = inp.value.trim();
        if (!v) return App.toast('Please enter your name', 'error');
        userData.name = v; advance();
      });
    }
    if (currentStep === 1) {
      const inp = el.querySelector('#ob-age');
      if (next) next.addEventListener('click', () => {
        const v = parseInt(inp.value);
        if (!v || v < 13 || v > 99) return App.toast('Enter a valid age', 'error');
        userData.age = v; advance();
      });
    }
    if (currentStep === 2) {
      el.querySelector('#unit-metric').addEventListener('click', () => { userData.units = 'metric'; renderStep(el); });
      el.querySelector('#unit-imperial').addEventListener('click', () => { userData.units = 'imperial'; renderStep(el); });
      if (next) next.addEventListener('click', () => {
        const h = el.querySelector('#ob-height').value;
        const w = el.querySelector('#ob-weight').value;
        if (!h || !w) return App.toast('Please enter your height and weight', 'error');
        userData.height = h;
        userData.weight = w;
        advance();
      });
    }
    if (currentStep === 3) {
      el.querySelectorAll('[data-goal]').forEach(card => {
        card.addEventListener('click', () => {
          userData.goal = card.dataset.goal;
          el.querySelectorAll('[data-goal]').forEach(c => c.classList.remove('selected'));
          card.classList.add('selected');
          next.disabled = false;
        });
      });
      if (next) next.addEventListener('click', advance);
    }
    if (currentStep === 4) {
      el.querySelectorAll('[data-level]').forEach(card => {
        card.addEventListener('click', () => {
          userData.level = card.dataset.level;
          el.querySelectorAll('[data-level]').forEach(c => c.classList.remove('selected'));
          card.classList.add('selected');
          next.disabled = false;
        });
      });
      if (next) next.addEventListener('click', advance);
    }
    if (currentStep === 5) {
      el.querySelectorAll('.day-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          const d = parseInt(pill.dataset.day);
          if (userData.freeDays.includes(d)) {
            userData.freeDays = userData.freeDays.filter(x => x !== d);
            pill.classList.remove('selected');
          } else {
            userData.freeDays.push(d); pill.classList.add('selected');
          }
          next.disabled = userData.freeDays.length < 2;
        });
      });
      if (next) next.addEventListener('click', advance);
    }
    if (currentStep === 6) {
      el.querySelectorAll('[data-loc]').forEach(card => {
        card.addEventListener('click', () => {
          const loc = card.dataset.loc;
          if (loc === 'gym') { App.toast('Gym mode coming soon — we\'re working on something serious 💪'); return; }
          userData.location = loc;
          el.querySelectorAll('[data-loc]').forEach(c => c.classList.remove('selected'));
          card.classList.add('selected');
          next.disabled = false;
        });
      });
      if (next) next.addEventListener('click', advance);
    }
    if (currentStep === 7) {
      const allowCam = el.querySelector('#ob-allow-camera');
      const allowNotif = el.querySelector('#ob-allow-notif');
      if (allowCam) allowCam.addEventListener('click', async () => {
        try {
          await navigator.mediaDevices.getUserMedia({ video: true });
          allowCam.textContent = '✅ Camera allowed'; allowCam.disabled = true;
        } catch { App.toast('Camera permission denied. You can change this in Settings.', 'error'); }
      });
      if (allowNotif) allowNotif.addEventListener('click', async () => {
        if ('Notification' in window) {
          const perm = await Notification.requestPermission();
          if (perm === 'granted') { allowNotif.textContent = '✅ Notifications allowed'; allowNotif.disabled = true; }
          else App.toast('Notifications denied — you can enable them in Settings.', 'error');
        }
      });
      if (next) next.addEventListener('click', advance);
    }
    if (currentStep === 8) {
      runPlanGeneration(el);
    }
  }

  function runPlanGeneration(el) {
    const steps = ['ps1', 'ps2', 'ps3', 'ps4'];
    const fill = el.querySelector('#plan-progress-fill');
    let i = 0;
    const interval = setInterval(() => {
      if (i < steps.length) {
        if (i > 0) {
          const prev = el.querySelector(`#${steps[i - 1]}`);
          if (prev) { prev.classList.remove('active'); prev.classList.add('done'); prev.querySelector('.step-icon').textContent = '✓'; }
        }
        const cur = el.querySelector(`#${steps[i]}`);
        if (cur) { cur.classList.add('active'); cur.querySelector('.step-icon').textContent = '●'; }
        fill.style.width = ((i + 1) / steps.length * 100) + '%';
        i++;
      } else {
        clearInterval(interval);
        const lastEl = el.querySelector(`#${steps[steps.length - 1]}`);
        if (lastEl) { lastEl.classList.remove('active'); lastEl.classList.add('done'); lastEl.querySelector('.step-icon').textContent = '✓'; }
        // Save user and generate plan
        Storage.setUser(userData);
        const plan = WorkoutLib.generatePlan(userData);
        Storage.setPlan(plan);
        Storage.markOnboardingDone();
        setTimeout(() => showPlanResult(el, plan), 600);
      }
    }, 900);
  }

  function showPlanResult(el, plan) {
    el.querySelector('#plan-progress-fill').style.width = '100%';
    const result = el.querySelector('#plan-result');
    if (!result) return;
    result.style.display = 'block';
    result.innerHTML = `
      <h3 style="font-family:var(--font-display);font-size:28px;margin-bottom:16px;color:var(--text)">Your Plan 🎯</h3>
      <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:28px">
        ${plan.map(d => `
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--card);border-radius:8px;border:1px solid ${d.isRest ? 'var(--border)' : 'rgba(232,80,10,0.25)'}">
            <span style="font-size:13px;color:var(--muted);font-weight:700;letter-spacing:1px">${d.name.toUpperCase().slice(0,3)}</span>
            <span style="font-weight:600;flex:1;margin-left:16px">${d.emoji} ${d.workoutName}</span>
            ${!d.isRest ? `<span style="font-size:12px;color:var(--muted)">${d.estimatedMin}min</span>` : ''}
          </div>`).join('')}
      </div>
      <button class="btn btn-primary btn-full btn-xl" id="ob-finish">Let's Get Started 🔥</button>`;
    result.querySelector('#ob-finish').addEventListener('click', () => App.navigate('home'));
  }

  return { mount };
})();

window.OnboardingScreen = OnboardingScreen;
