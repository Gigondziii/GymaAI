// ============================================
// GYMA — SCHEDULE SCREEN
// ============================================
const ScheduleScreen = (() => {
  function mount(el) {
    el.id = 'screen-schedule';
    el.className = 'screen active';
    const plan = Storage.getPlan() || [];
    const history = Storage.getHistory();
    const todayIdx = (new Date().getDay() + 6) % 7;
    el.innerHTML = `
      <div style="padding:56px 24px 32px">
        <h1 class="schedule-header">Schedule</h1>
        <div class="schedule-week" id="schedule-week"></div>
      </div>`;
    const week = el.querySelector('#schedule-week');
    plan.forEach((d, i) => {
      const isToday = i === todayIdx;
      const isDone = history.some(h => {
        const hDate = new Date(h.date);
        const targetDate = new Date();
        targetDate.setDate(targetDate.getDate() - todayIdx + i);
        return hDate.toDateString() === targetDate.toDateString();
      });
      const dayCard = document.createElement('div');
      dayCard.className = `schedule-day ${isToday ? 'today' : ''}`;
      dayCard.innerHTML = `
        <div class="schedule-day-header">
          <div>
            <div class="schedule-day-name ${isToday ? 'today' : ''}">${d.name.toUpperCase()}${isToday ? ' — TODAY' : ''}</div>
            <div class="schedule-day-workout">${d.emoji} ${d.workoutName}</div>
          </div>
          <div class="schedule-day-badge ${isDone ? 'done' : isToday && !d.isRest ? 'today-badge' : 'rest'}">
            ${isDone ? '✅ Done' : isToday && !d.isRest ? 'Today' : d.isRest ? 'Rest' : ''}
          </div>
        </div>
        ${!d.isRest ? `<div class="schedule-day-exercises" id="sched-ex-${i}">
          ${(d.exercises||[]).map(ek => {
            const ex = WorkoutLib.EXERCISES[ek];
            return ex ? `<div class="schedule-ex-item">${ex.emoji} ${ex.name} — ${ex.sets}×${ex.reps||ex.durationSec+'s'}</div>` : '';
          }).join('')}
        </div>` : ''}`;
      dayCard.addEventListener('click', () => {
        const exList = dayCard.querySelector(`#sched-ex-${i}`);
        if (exList) exList.classList.toggle('open');
      });
      if (isToday && !d.isRest && !isDone) {
        const trainBtn = document.createElement('button');
        trainBtn.className = 'btn btn-primary btn-full';
        trainBtn.style.cssText = 'border-radius:0;border-top:1px solid var(--border);';
        trainBtn.textContent = '▶ Train Now';
        trainBtn.addEventListener('click', e => { e.stopPropagation(); App.startWorkout({ dayPlan: d }); });
        dayCard.appendChild(trainBtn);
      }
      week.appendChild(dayCard);
    });
  }
  return { mount };
})();
window.ScheduleScreen = ScheduleScreen;
