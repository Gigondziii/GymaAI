// ============================================
// GYMA — SPLASH SCREEN
// ============================================

const SplashScreen = (() => {
  function mount(el) {
    el.id = 'screen-splash';
    el.className = 'screen active';
    el.innerHTML = `
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100dvh;padding:40px 32px">
        <div class="splash-logo">
          <div class="splash-letters" id="splash-letters"></div>
          <div class="splash-underline" style="max-width:260px;width:100%"></div>
          <p class="splash-tagline">your ai trainer</p>
        </div>
        <div class="splash-buttons">
          <button class="btn btn-primary btn-xl btn-full" id="btn-start">Let's Get Started</button>
        </div>
      </div>`;

    // Animate letters
    const lettersEl = el.querySelector('#splash-letters');
    'GYMA'.split('').forEach((ch, i) => {
      const span = document.createElement('span');
      span.className = 'splash-letter';
      span.textContent = ch;
      span.style.animationDelay = `${0.1 + i * 0.12}s`;
      lettersEl.appendChild(span);
    });

    el.querySelector('#btn-start').addEventListener('click', () => {
      const user = Storage.getUser();
      if (user && Storage.isOnboardingDone()) App.navigate('home');
      else App.navigate('onboarding');
    });
  }

  return { mount };
})();

window.SplashScreen = SplashScreen;
