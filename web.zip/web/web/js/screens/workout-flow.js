// ============================================
// GYMA — FULL WORKOUT FLOW
// pre-brief → camera-setup → session → rest → complete → review
// ============================================

const WorkoutFlow = (() => {
  let sessionState = {};

  // ── VIDEO INTRO (replaces old PRE-BRIEF) ──────────────────────
  function mountPreBrief(el, { dayPlan }) {
    el.id = 'screen-pre-brief';
    el.className = 'screen active';
    el.style.background = '#000';
    
    const vName = dayPlan.workoutName || 'Workout';
    el.innerHTML = `
      <div style="position:absolute;inset:0;z-index:500;background:#000;display:flex;align-items:center;justify-content:center">
        <video id="workout-intro-video" src="Workouts/${vName}.mp4" style="width:100%;height:100%;object-fit:cover" autoplay muted playsinline></video>
        <div id="video-fallback-msg" style="position:absolute;color:white;font-size:24px;text-align:center;font-family:var(--font-display);display:none;width:100%;padding:0 24px">
          VIDEO NOT FOUND<br/><span style="font-size:16px;color:var(--muted)">we need money for animations :D</span>
        </div>
        <button id="dev-skip-vid" style="position:absolute;bottom:32px;background:rgba(255,255,255,0.2);border:none;padding:12px 24px;border-radius:24px;color:white;font-size:14px;display:none;z-index:600">Skip Intro</button>
      </div>
    `;

    const v = el.querySelector('#workout-intro-video');
    const msg = el.querySelector('#video-fallback-msg');
    const skipBtn = el.querySelector('#dev-skip-vid');
    
    let started = false;
    const beginCamera = () => {
      if (started) return; started = true;
      App.navigate('camera-setup', { dayPlan });
    };

    skipBtn.addEventListener('click', beginCamera);

    v.onended = beginCamera;
    v.onerror = () => {
      v.style.display = 'none';
      msg.style.display = 'block';
      skipBtn.style.display = 'block';
      setTimeout(beginCamera, 3000);
    };

    const playPromise = v.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {
        v.style.display = 'none';
        msg.style.display = 'block';
        skipBtn.style.display = 'block';
        setTimeout(beginCamera, 3000);
      });
    }
  }

  // ── CAMERA SETUP ───────────────────────────────────────────
  function mountCameraSetup(el, { dayPlan }) {
    el.id = 'screen-camera-setup';
    el.className = 'screen active';
    el.style.background = '#000';
    el.style.padding = '0';
    const cameraLayer = document.getElementById('camera-layer');
    cameraLayer.classList.remove('hidden');

    el.innerHTML = `
      <div class="camera-ui-overlay">
        <div>
          <button id="cam-back" style="background:rgba(0,0,0,0.5);border:none;color:white;width:44px;height:44px;border-radius:50%;font-size:20px;cursor:pointer">←</button>
        </div>
        <div class="camera-setup-hud">
          <div class="body-silhouette" id="body-silhouette"></div>
          <div id="direction-hints"></div>
          <div class="camera-status-pill" id="cam-status">Stand inside the outline 📍</div>
          <div id="cam-countdown" class="countdown-overlay" style="display:none"></div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:12px">
          <div style="height:4px;background:rgba(255,255,255,0.1);border-radius:2px;width:100%;overflow:hidden">
            <div id="conf-bar-fill" style="width:0%;height:100%;background:var(--orange);border-radius:2px;transition:width 0.3s"></div>
          </div>
          <button class="btn btn-primary" id="cam-confirm" disabled>Confirm Position</button>
        </div>
      </div>`;

    el.querySelector('#cam-back').addEventListener('click', () => { stopCamera(); App.navigate('home'); });

    const video = document.getElementById('workout-video');
    const canvas = document.getElementById('pose-canvas');
    let confidence = 0;
    let confirmTimer = null;
    let counting = false;

    startCamera(video).then(() => {
      PoseDetector.start(video, canvas, ({ landmarks, confidence: c }) => {
        confidence = c;
        const fill = el.querySelector('#conf-bar-fill');
        const status = el.querySelector('#cam-status');
        const confirm = el.querySelector('#cam-confirm');
        if (fill) fill.style.width = Math.round(c * 100) + '%';
        if (c > 0.75) {
          if (status) { status.textContent = '✅ Perfect position! Hold still...'; status.classList.add('detected'); }
          if (confirm) confirm.disabled = false;
          if (!counting) { counting = true; startCountdown(el, dayPlan); }
        } else {
          if (status) { status.textContent = c > 0.4 ? 'Getting there... step back a bit ↑' : 'Stand inside the outline 📍'; status.classList.remove('detected'); }
          if (confirm) confirm.disabled = true;
          if (counting) { counting = false; clearTimeout(confirmTimer); hideCountdown(el); }
        }
      });
    });

    el.querySelector('#cam-confirm').addEventListener('click', () => {
      PoseDetector.stop();
      cameraLayer.classList.add('hidden');
      App.navigate('session', { dayPlan });
    });
  }

  async function startCamera(video) {
    console.log('[Camera] Starting local webcam');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      video.srcObject = stream;
      await new Promise(resolve => {
        video.onloadedmetadata = () => resolve();
      });
      await video.play();
    } catch (err) {
      console.error('[Camera] Error accessing webcam:', err);
      alert('Camera access is required for GYMA to work!');
    }
  }

  function stopCamera() {
    PoseDetector.stop();
    const video = document.getElementById('workout-video');
    if (video && video.srcObject) {
      video.srcObject.getTracks().forEach(track => track.stop());
      video.srcObject = null;
    }
    document.getElementById('camera-layer').classList.add('hidden');
  }

  let countdownInterval = null;
  function startCountdown(el, dayPlan) {
    let c = 3;
    const cdEl = el.querySelector('#cam-countdown');
    if (cdEl) cdEl.style.display = 'block';
    countdownInterval = setInterval(() => {
      const cd = el.querySelector('#cam-countdown');
      if (!cd) { clearInterval(countdownInterval); return; }
      cd.textContent = c > 0 ? c : 'GO!';
      c--;
      if (c < -1) {
        clearInterval(countdownInterval);
        PoseDetector.stop();
        document.getElementById('camera-layer').classList.add('hidden');
        App.navigate('session', { dayPlan });
      }
    }, 1000);
  }

  function hideCountdown(el) {
    clearInterval(countdownInterval);
    const cd = el.querySelector('#cam-countdown');
    if (cd) cd.style.display = 'none';
  }

  // ── LIVE SESSION ───────────────────────────────────────────
  function mountSession(el, { dayPlan }) {
    el.id = 'screen-session';
    el.className = 'screen active';
    el.style.background = '#000';

    const exercises = dayPlan.exercises || [];
    sessionState = {
      dayPlan, exercises,
      exerciseIdx: 0,
      setIdx: 0,
      repCount: 0,
      formResults: [],
      totalReps: 0,
      formErrors: 0,
      startTime: Date.now(),
      history: [],
      repCounter: null,
      formAnalyzer: null,
    };

    const cameraLayer = document.getElementById('camera-layer');
    cameraLayer.classList.remove('hidden');

    el.innerHTML = `
      <div class="camera-ui-overlay">
        <div class="session-top-hud">
          <div class="session-exercise-name" id="sess-exercise-name"></div>
          <div class="session-set-info" id="sess-set-info"></div>
          <div style="position:absolute;top:56px;right:24px">
            <button id="sess-quit" style="background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.1);color:var(--muted);padding:6px 12px;border-radius:8px;font-size:13px;cursor:pointer">End</button>
          </div>
        </div>
        <div class="session-bottom-hud">
          <div class="rep-counter" id="sess-rep-count">0</div>
          <div class="form-feedback-bar"><div class="form-feedback-fill" id="sess-form-fill" style="width:100%;background:var(--success)"></div></div>
          <div class="form-cue correct" id="sess-form-cue">Ready — press Start Exercise</div>
          <button class="btn btn-primary btn-full btn-xl" id="sess-start" style="margin-top:12px">▶ Start Exercise</button>
          <button class="btn btn-secondary btn-full" id="sess-done-set" style="display:none;margin-top:12px">Done — Next Set →</button>
        </div>
      </div>`;

    el.querySelector('#sess-quit').addEventListener('click', () => {
      const modal = document.createElement('div');
      modal.className = 'modal-backdrop';
      modal.innerHTML = `<div class="modal"><h3>End Session?</h3><p>You'll lose this session's progress. Are you sure?</p>
        <div style="display:flex;gap:12px">
          <button class="btn btn-secondary btn-full" id="quit-keep">Keep Going 💪</button>
          <button class="btn btn-danger" id="quit-yes">Quit</button>
        </div></div>`;
      modal.querySelector('#quit-keep').addEventListener('click', () => modal.remove());
      modal.querySelector('#quit-yes').addEventListener('click', () => { 
        if (sessionState.mediaRecorder && sessionState.mediaRecorder.state !== "inactive") sessionState.mediaRecorder.stop();
        stopCamera(); modal.remove(); App.navigate('home'); 
      });
      document.body.appendChild(modal);
    });

    el.querySelector('#sess-start').addEventListener('click', startExercise.bind(null, el));
    el.querySelector('#sess-done-set').addEventListener('click', () => advanceSet(el));

    updateSessionUI(el);
    startVideoBackground();

    const canvas = document.getElementById('pose-canvas');
    if (canvas && canvas.captureStream) {
      try {
        const stream = canvas.captureStream(30);
        sessionState.mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
        sessionState.recordedChunks = [];
        sessionState.mediaRecorder.ondataavailable = e => { if (e.data.size > 0) sessionState.recordedChunks.push(e.data); };
        sessionState.mediaRecorder.onstop = () => {
          const blob = new Blob(sessionState.recordedChunks, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.style.display = 'none';
          a.href = url;
          a.download = `GYMA_Session_${Date.now()}.webm`;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
        };
        sessionState.mediaRecorder.start();
      } catch (e) { console.warn("MediaRecorder issue:", e); }
    }
  }

  function startVideoBackground() {
    const video = document.getElementById('workout-video');
    const canvas = document.getElementById('pose-canvas');
    document.getElementById('camera-layer').classList.remove('hidden');
    startCamera(video).then(() => {
      PoseDetector.start(video, canvas, ({ landmarks, confidence }) => {
        if (!landmarks || !sessionState.active) return;
        processFrame(landmarks.angles || landmarks, canvas);
      });
    });
  }

  function startExercise(el) {
    const ek = sessionState.exercises[sessionState.exerciseIdx];
    const ex = WorkoutLib.EXERCISES[ek];
    sessionState.active = true;
    sessionState.repCounter = new RepCounter(ek);
    sessionState.formAnalyzer = new FormAnalyzer(ek);
    el.querySelector('#sess-start').style.display = 'none';
    el.querySelector('#sess-done-set').style.display = 'none'; // NEVER SHOW

    if (ex?.reps === null) {
      // Timed exercise
      let remaining = ex.durationSec || 45;
      const repEl = document.getElementById('sess-rep-count');
      if (repEl) repEl.style.fontSize = '48px';
      const timer = setInterval(() => {
        remaining--;
        if (repEl) repEl.textContent = remaining + 's';
        if (remaining <= 0) { clearInterval(timer); advanceSet(el); }
      }, 1000);
    }
  }

  function processFrame(angles, canvas) {
    if (!sessionState.formAnalyzer || !sessionState.active) return;
    const formResult = sessionState.formAnalyzer.analyze(angles);
    sessionState.formResults.push(formResult);

    const cueEl = document.getElementById('sess-form-cue');
    const fillEl = document.getElementById('sess-form-fill');
    if (cueEl) { cueEl.textContent = formResult.message; cueEl.className = `form-cue ${formResult.status}`; }
    if (fillEl) {
      const score = formResult.status === 'correct' ? 100 : formResult.status === 'warning' ? 60 : 20;
      const color = formResult.status === 'correct' ? 'var(--success)' : formResult.status === 'warning' ? 'var(--warning)' : 'var(--error)';
      fillEl.style.width = score + '%'; fillEl.style.background = color;
    }

    if (formResult.status === 'error') {
      sessionState.formErrors++;
      flashError();
      if (navigator.vibrate) navigator.vibrate([100]);
      if (formResult.issues?.length) {
        const issue = formResult.issues.find(i => i.status === 'error');
        if (issue) {
          const c2 = document.createElement('canvas');
          c2.width = canvas.width; c2.height = canvas.height;
          const ctx2 = c2.getContext('2d');
          ctx2.drawImage(canvas, 0, 0);
          ctx2.strokeStyle = 'red'; ctx2.lineWidth = 10;
          ctx2.strokeRect(0, 0, canvas.width, canvas.height);
          ctx2.fillStyle = 'rgba(255, 0, 0, 0.7)';
          ctx2.fillRect(0, canvas.height - 60, canvas.width, 60);
          ctx2.fillStyle = 'white'; ctx2.font = '24px "DM Sans", sans-serif';
          ctx2.fillText(`⚠️ ${formResult.message}`, 20, canvas.height - 20);

          Storage.addMistake({
            exercise: sessionState.exercises[sessionState.exerciseIdx],
            set: sessionState.setIdx + 1, rep: sessionState.repCount,
            joint: issue.joint, angle: issue.angle, ideal: issue.ideal,
            frame: c2.toDataURL('image/jpeg', 0.6),
            timestamp: new Date().toISOString(),
          });
        }
      }
    }

    if (sessionState.repCounter) {
      const count = sessionState.repCounter.update(angles);
      if (count !== sessionState.repCount) {
        sessionState.repCount = count;
        sessionState.totalReps++;
        const repEl = document.getElementById('sess-rep-count');
        if (repEl) {
          repEl.textContent = count;
          repEl.animate([{ transform: 'scale(1.3)' }, { transform: 'scale(1)' }], { duration: 200, easing: 'cubic-bezier(0.16,1,0.3,1)' });
        }
        const ek = sessionState.exercises[sessionState.exerciseIdx];
        const ex = WorkoutLib.EXERCISES[ek];
        if (ex?.reps && count >= ex.reps) setTimeout(() => advanceSet(el), 500);
      }
    }
  }

  function flashError() {
    const flash = document.createElement('div');
    flash.className = 'error-flash';
    document.body.appendChild(flash);
    setTimeout(() => flash.remove(), 500);
  }

  function advanceSet(el) {
    sessionState.active = false;
    const ek = sessionState.exercises[sessionState.exerciseIdx];
    const ex = WorkoutLib.EXERCISES[ek];
    const totalSets = ex?.sets || sessionState.dayPlan.sets || 3;
    sessionState.history.push({ exercise: ek, set: sessionState.setIdx, reps: sessionState.repCount });
    sessionState.repCounter?.reset();
    sessionState.repCount = 0;

    if (sessionState.setIdx < totalSets - 1) {
      sessionState.setIdx++;
      App.navigate('rest', { dayPlan: sessionState.dayPlan, nextLabel: `Set ${sessionState.setIdx + 1} of ${totalSets} — ${ex?.name}`, restSec: ex?.restSec || 60 });
    } else {
      sessionState.setIdx = 0;
      sessionState.exerciseIdx++;
      if (sessionState.exerciseIdx < sessionState.exercises.length) {
        const nextEk = sessionState.exercises[sessionState.exerciseIdx];
        const nextEx = WorkoutLib.EXERCISES[nextEk];
        App.navigate('rest', { dayPlan: sessionState.dayPlan, nextLabel: `Next: ${nextEx?.name || 'Exercise'}`, restSec: 90 });
      } else {
        finishWorkout();
      }
    }
  }

  function updateSessionUI(el) {
    const ek = sessionState.exercises[sessionState.exerciseIdx];
    const ex = WorkoutLib.EXERCISES[ek];
    const totalSets = ex?.sets || sessionState.dayPlan.sets || 3;
    const nameEl = el.querySelector('#sess-exercise-name');
    const setEl = el.querySelector('#sess-set-info');
    if (nameEl) nameEl.textContent = `${ex?.emoji || '💪'} ${ex?.name || ek}`;
    if (setEl) setEl.textContent = `Set ${sessionState.setIdx + 1} of ${totalSets} · ${sessionState.exerciseIdx + 1}/${sessionState.exercises.length} exercises`;
  }

  function finishWorkout() {
    stopCamera();
    if (sessionState.mediaRecorder && sessionState.mediaRecorder.state !== "inactive") {
      sessionState.mediaRecorder.stop();
    }
    const durationSec = Math.round((Date.now() - sessionState.startTime) / 1000);
    const allFormResults = sessionState.formResults;
    const formScore = WorkoutLib.calcFormScore(allFormResults);
    const session = {
      id: `s_${Date.now()}`,
      date: new Date().toISOString(),
      workoutType: sessionState.dayPlan.workoutType,
      workoutName: sessionState.dayPlan.workoutName,
      durationSec,
      totalReps: sessionState.totalReps,
      exercises: sessionState.exercises.length,
      formScore,
      formErrors: sessionState.formErrors,
      mistakes: Storage.getMistakes().slice(0, 20),
    };
    Storage.addSession(session);
    App.navigate('complete', { session });
  }

  // ── REST ──────────────────────────────────────────────────
  function mountRest(el, { dayPlan, nextLabel, restSec }) {
    el.id = 'screen-rest';
    el.className = 'screen active';
    let remaining = restSec || 60;
    let unlocked = false;

    el.innerHTML = `
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:48px 24px">
        <div style="font-size:40px">😮‍💨</div>
        <h2 style="font-family:var(--font-display);font-size:48px;line-height:1">Rest</h2>
        <div class="rest-countdown mono" id="rest-timer">${fmtTime(remaining)}</div>
        <div class="rest-next-label">NEXT UP</div>
        <div class="rest-next">${nextLabel}</div>
      </div>
      <div style="padding:0 24px 48px">
        <button class="btn btn-secondary btn-full btn-xl" id="rest-continue" disabled>
          🔒 Hydrate & Recover (${remaining}s)
        </button>
      </div>`;

    const timerEl = el.querySelector('#rest-timer');
    const contBtn = el.querySelector('#rest-continue');
    const interval = setInterval(() => {
      remaining--;
      if (timerEl) {
        timerEl.textContent = fmtTime(remaining);
        if (remaining <= 10) timerEl.classList.add('soon');
        if (contBtn) contBtn.textContent = `🔒 Hydrate & Recover (${remaining}s)`;
      }
      if (remaining <= 0 && !unlocked) {
        clearInterval(interval);
        continueSession(dayPlan);
      }
    }, 1000);

    contBtn.addEventListener('click', () => { clearInterval(interval); continueSession(dayPlan); });
  }

  function continueSession(dayPlan) {
    App.navigate('session', { dayPlan });
    // Refresh session screen with current state
    setTimeout(() => {
      const el = document.getElementById('screen-session');
      if (el) {
        updateSessionUI(el);
        el.querySelector('#sess-start').style.display = 'block';
        el.querySelector('#sess-done-set').style.display = 'none';
        el.querySelector('#sess-rep-count').textContent = '0';
      }
    }, 100);
  }

  function fmtTime(s) {
    return `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;
  }

  // ── COMPLETE ──────────────────────────────────────────────
  function mountComplete(el, { session }) {
    el.id = 'screen-complete';
    el.className = 'screen active';
    const grade = WorkoutLib.getFormGrade(session.formScore);

    el.innerHTML = `
      <div style="text-align:center;padding:56px 24px 24px">
        <div style="font-size:56px;margin-bottom:8px">🏆</div>
        <div class="complete-title">WORKOUT<br/>COMPLETE</div>
      </div>
      <div class="complete-stats" style="margin:0 24px">
        <div class="complete-stat"><div class="complete-stat-value">${fmtTime(session.durationSec)}</div><div class="complete-stat-label">Duration</div></div>
        <div class="complete-stat"><div class="complete-stat-value">${session.totalReps}</div><div class="complete-stat-label">Total Reps</div></div>
        <div class="complete-stat"><div class="complete-stat-value">${session.exercises}</div><div class="complete-stat-label">Exercises</div></div>
        <div class="complete-stat"><div class="complete-stat-value">${session.formScore}%</div><div class="complete-stat-label">Form Score</div></div>
      </div>
      <div style="padding:24px;display:flex;flex-direction:column;align-items:center;gap:12px">
        <p style="font-size:14px;color:var(--muted);text-align:center">Your muscles need recovery.</p>
        <div class="breathing-circle"></div>
        <div style="font-family:var(--font-mono);color:var(--orange);font-size:36px;font-weight:700" id="rest-cd">2:00</div>
        <p style="font-size:13px;color:var(--dimmed);text-align:center;font-style:italic">"The pain you feel today will be the strength you feel tomorrow."</p>
        <p style="font-size:12px;color:var(--dimmed)" id="rest-cd-label">Hold on... review unlocks in 2:00</p>
      </div>
      <div style="padding:0 24px 48px">
        <button class="btn btn-primary btn-full btn-xl" id="btn-review" disabled>Review Session 🎬</button>
      </div>`;

    launchSessionConfetti();

    let remaining = 120;
    const cdEl = el.querySelector('#rest-cd');
    const cdLabel = el.querySelector('#rest-cd-label');
    const reviewBtn = el.querySelector('#btn-review');
    const interval = setInterval(() => {
      remaining--;
      if (cdEl) cdEl.textContent = fmtTime(remaining);
      if (cdLabel) cdLabel.textContent = `Review unlocks in ${fmtTime(remaining)}`;
      if (remaining <= 0) {
        clearInterval(interval);
        if (reviewBtn) { reviewBtn.disabled = false; if (cdLabel) cdLabel.textContent = 'Review unlocked 🎬'; }
      }
    }, 1000);

    reviewBtn.addEventListener('click', () => { clearInterval(interval); App.navigate('review', { session }); });
  }

  // ── REVIEW ────────────────────────────────────────────────
  function mountReview(el, { session }) {
    el.id = 'screen-review';
    el.className = 'screen active';
    const grade = WorkoutLib.getFormGrade(session.formScore);
    const mistakes = session.mistakes || [];
    const byExercise = {};
    mistakes.forEach(m => { if (!byExercise[m.exercise]) byExercise[m.exercise] = []; byExercise[m.exercise].push(m); });

    const mistakeHTML = Object.entries(byExercise).map(([ek, mList]) => {
      const ex = WorkoutLib.EXERCISES[ek];
      return `<div class="review-exercise">
        <div class="review-ex-header">${ex?.emoji || '💪'} ${ex?.name || ek}</div>
        ${mList.slice(0,3).map(m => `
          <div class="mistake-frame">
            ${m.frame ? `<img class="mistake-frame-img" src="${m.frame}" alt="frame"/>` : `<div style="height:100px;background:var(--elevated);display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:13px">No frame captured</div>`}
            <div class="mistake-detail">
              <div class="mistake-angle">Set ${m.set} · Rep ${m.rep} · ${m.joint.replace('_',' ')}: <strong>${m.angle}°</strong> (ideal: ${m.ideal?.[0]}–${m.ideal?.[1]}°)</div>
              <p style="font-size:13px;color:var(--muted);margin-top:4px">${m.angle < (m.ideal?.[0]||0) ? 'Go lower / deeper' : 'Straighten up'}</p>
            </div>
          </div>`).join('')}
      </div>`;
    }).join('');

    el.innerHTML = `
      <div style="padding:56px 24px 24px">
        <h2 style="font-family:var(--font-display);font-size:40px">Session Review</h2>
        <p style="color:var(--muted);margin-top:4px">Let's break down your ${session.workoutName}</p>
      </div>
      <div style="padding:0 24px 32px">
        ${mistakes.length === 0
          ? '<div class="card" style="text-align:center;padding:32px"><div style="font-size:48px">🏆</div><h3 style="font-family:var(--font-display);font-size:28px;margin-top:12px">Flawless Session!</h3><p style="color:var(--muted);margin-top:8px">Zero form errors detected. Keep it up!</p></div>'
          : mistakeHTML}
        <div class="grade-badge ${grade}">
          <div style="font-size:13px;font-family:var(--font-body);font-weight:700;letter-spacing:2px;color:var(--muted);margin-bottom:8px">FORM GRADE</div>
          ${grade}
        </div>
        <button class="btn btn-primary btn-full btn-xl" id="btn-save">Save & Continue →</button>
      </div>`;

    el.querySelector('#btn-save').addEventListener('click', () => App.navigate('home'));
  }

  function launchSessionConfetti() {
    const container = document.getElementById('confetti-container');
    const colors = ['#E8500A', '#C23B22', '#FF6B2B', '#F0F0F0'];
    for (let i = 0; i < 80; i++) {
      const p = document.createElement('div');
      p.className = 'confetti-piece';
      p.style.cssText = `left:${Math.random()*100}%;background:${colors[Math.floor(Math.random()*colors.length)]};width:${6+Math.random()*8}px;height:${6+Math.random()*8}px;border-radius:${Math.random()>0.5?'50%':'2px'};animation-duration:${1.5+Math.random()*2}s;animation-delay:${Math.random()*0.5}s`;
      container.appendChild(p);
      setTimeout(() => p.remove(), 4000);
    }
  }

  return { mountPreBrief, mountCameraSetup, mountSession, mountRest, mountComplete, mountReview };
})();

window.WorkoutFlow = WorkoutFlow;
