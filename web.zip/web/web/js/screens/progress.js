// ============================================
// GYMA — PROGRESS SCREEN
// ============================================
const ProgressScreen = (() => {
  function mount(el) {
    el.id = 'screen-progress';
    el.className = 'screen active';
    const history = Storage.getHistory();
    const streak = WorkoutLib.calcStreak(history);
    const totalMin = history.reduce((s, h) => s + Math.round((h.durationSec||0)/60), 0);
    const avgForm = history.length
      ? Math.round(history.reduce((s, h) => s + (h.formScore||0), 0) / history.length)
      : 0;

    // Weekly counts (last 7 days)
    const today = new Date();
    const weekData = Array.from({length:7}, (_, i) => {
      const d = new Date(today); d.setDate(today.getDate() - 6 + i);
      const count = history.filter(h => new Date(h.date).toDateString() === d.toDateString()).length;
      return { label: ['M','T','W','T','F','S','S'][(d.getDay()+6)%7], count };
    });

    // Form scores
    const formScores = history.slice(0, 10).reverse().map(h => h.formScore || 0);

    // Active dates for heatmap
    const activeDates = history.map(h => h.date.split('T')[0]);

    // PRs (best form score per exercise)
    const prs = {};
    history.forEach(h => {
      if (h.workoutName && (h.formScore || 0) > (prs[h.workoutName] || 0)) {
        prs[h.workoutName] = h.formScore;
      }
    });

    el.innerHTML = `
      <div style="padding:56px 24px 32px">
        <h1 class="progress-header">Progress</h1>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px">
          <div class="card" style="text-align:center">
            <div style="font-size:32px;font-family:var(--font-mono);color:var(--orange);font-weight:700">${history.length}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px">Sessions</div>
          </div>
          <div class="card" style="text-align:center">
            <div style="font-size:32px;font-family:var(--font-mono);color:var(--orange);font-weight:700">${totalMin}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px">Minutes</div>
          </div>
          <div class="card" style="text-align:center">
            <div style="font-size:32px;font-family:var(--font-mono);color:var(--orange);font-weight:700">${streak}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px">Day Streak</div>
          </div>
          <div class="card" style="text-align:center">
            <div style="font-size:32px;font-family:var(--font-mono);color:var(--orange);font-weight:700">${avgForm}%</div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px">Avg Form</div>
          </div>
        </div>

        <div class="progress-charts">
          <div class="chart-card">
            <div class="chart-title">Weekly Training</div>
            <canvas class="chart-canvas" id="chart-weekly" data-height="140"></canvas>
          </div>
          <div class="chart-card">
            <div class="chart-title">Form Score Trend</div>
            <canvas class="chart-canvas" id="chart-form" data-height="140"></canvas>
          </div>
          <div class="chart-card">
            <div class="chart-title">Activity Heatmap</div>
            <div class="heatmap" id="heatmap"></div>
          </div>
          ${Object.keys(prs).length ? `
          <div class="chart-card">
            <div class="chart-title">Bests</div>
            <div class="pr-list">
              ${Object.entries(prs).slice(0,5).map(([name, score]) => `
                <div class="pr-item">
                  <span class="pr-exercise">${name}</span>
                  <span class="pr-value">${score}% form</span>
                </div>`).join('')}
            </div>
          </div>` : ''}
        </div>
      </div>`;

    // Render charts after paint
    requestAnimationFrame(() => {
      const weekCanvas = el.querySelector('#chart-weekly');
      const formCanvas = el.querySelector('#chart-form');
      if (weekCanvas) Charts.drawWeeklyBars(weekCanvas, weekData);
      if (formCanvas) Charts.drawFormLine(formCanvas, formScores);

      // Heatmap
      const heatmapEl = el.querySelector('#heatmap');
      if (heatmapEl) {
        for (let i = 83; i >= 0; i--) {
          const d = new Date(today); d.setDate(today.getDate() - i);
          const key = d.toISOString().split('T')[0];
          const cell = document.createElement('div');
          cell.className = `heatmap-cell ${activeDates.includes(key) ? 'active' : ''}`;
          cell.title = key;
          heatmapEl.appendChild(cell);
        }
      }
    });
  }
  return { mount };
})();
window.ProgressScreen = ProgressScreen;
