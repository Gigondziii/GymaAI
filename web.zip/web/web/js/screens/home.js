// ============================================
// GYMA — HOME SCREEN + SPOTLIGHT TUTORIAL
// ============================================

const HomeScreen = (() => {
  const TUTORIAL_STEPS = [
    { targetId: 'streak-widget', text: 'Your streak tracks consecutive training days. Keep it alive! 🔥' },
    { targetId: 'today-workout-card', text: "This is today's session. Tap to preview exercises." },
    { targetId: 'btn-start-workout', text: "When you're ready, hit this to begin." },
    { targetId: 'nav-progress', text: 'Track your improvement over time here.' },
    { targetId: 'nav-account', text: 'Your profile, settings, and plan are here.' },
  ];
  let tutorialStep = 0;
  let tutorialTimer = null;

  function mount(el) {
    el.id = 'screen-home';
    el.className = 'screen active';
    const user = Storage.getUser() || { name: 'Athlete' };
    const plan = Storage.getPlan() || [];
    const history = Storage.getHistory();
    const streak = WorkoutLib.calcStreak(history);
    const todayIdx = (new Date().getDay() + 6) % 7;
    const todayPlan = plan[todayIdx] || { isRest: true, workoutName: 'Rest', emoji: '💤' };
    const greeting = getGreeting();
    const dateStr = new Date().toLocaleDateString('en-US', { weekday:'long', month:'short', day:'numeric' });

    el.innerHTML = `
      <div class="home-header">
        <div class="home-greeting">${greeting},<br/>${user.name} 👋</div>
        <div class="home-date">${dateStr} · ${todayPlan.isRest ? 'Rest Day 💤' : `Today: ${todayPlan.workoutName}`}</div>
      </div>
      <div class="home-content">

        ${!todayPlan.isRest ? `
        <div class="today-workout-card" id="today-workout-card">
          <div class="today-card-top"></div>
          <div class="today-card-body">
            <div class="today-card-name">${todayPlan.emoji} ${todayPlan.workoutName}</div>
            <div class="today-card-meta">
              <span class="card-badge">${todayPlan.exercises ? todayPlan.exercises.length : 3} exercises</span>
              <span class="card-badge">${todayPlan.estimatedMin || 30} min</span>
              <span class="card-badge orange">${todayPlan.difficulty || 'Moderate'}</span>
            </div>
            <button class="preview-btn" id="preview-toggle">Preview exercises ▾</button>
          </div>
          <div class="exercise-list-preview" id="exercise-preview">
            ${(todayPlan.exercises || []).map(ek => {
              const ex = WorkoutLib.EXERCISES[ek];
              return ex ? `<div class="exercise-preview-item"><span>${ex.emoji} ${ex.name}</span><span>${ex.sets}×${ex.reps || ex.durationSec + 's'}</span></div>` : '';
            }).join('')}
          </div>
        </div>` : `
        <div class="card" style="text-align:center;padding:32px 20px" id="today-workout-card">
          <div style="font-size:48px;margin-bottom:8px">💤</div>
          <div class="today-card-name">Rest Day</div>
          <p style="color:var(--muted);font-size:14px;margin-top:8px">Recovery is part of the program. Tomorrow: ${getNextWorkoutName(plan, todayIdx)}</p>
          <button class="btn btn-ghost" style="margin-top:16px;width:100%" id="btn-do-different">Do a different workout</button>
        </div>`}

        <div class="streak-card" id="streak-widget">
          <span class="streak-flame">🔥</span>
          <div>
            <div class="streak-number">${streak}</div>
            <div class="streak-label">day streak</div>
          </div>
          <div style="margin-left:auto;text-align:right">
            <div style="font-size:13px;color:var(--muted)">${history.length} sessions</div>
            <div style="font-size:12px;color:var(--dimmed)">all time</div>
          </div>
        </div>

        <div>
          <p style="font-size:12px;color:var(--muted);letter-spacing:1px;font-weight:700;text-transform:uppercase;margin-bottom:10px">This Week</p>
          <div class="week-overview" id="week-overview">${buildWeekOverview(plan, history)}</div>
        </div>

      </div>
      <div class="home-cta">
        <button class="btn-cta" id="btn-start-workout">
          ${todayPlan.isRest ? '▶ TRAIN ANYWAY' : '▶ START WORKOUT'}
        </button>
      </div>`;

    // Events
    const previewToggle = el.querySelector('#preview-toggle');
    const preview = el.querySelector('#exercise-preview');
    if (previewToggle && preview) {
      previewToggle.addEventListener('click', () => {
        preview.classList.toggle('open');
        previewToggle.textContent = preview.classList.contains('open') ? 'Hide exercises ▴' : 'Preview exercises ▾';
      });
    }

    const startBtn = el.querySelector('#btn-start-workout');
    startBtn.addEventListener('click', () => {
      if (todayPlan.isRest) {
        showDayPickerModal(plan, todayIdx);
      } else {
        App.startWorkout({ dayPlan: todayPlan });
      }
    });

    const diffBtn = el.querySelector('#btn-do-different');
    if (diffBtn) diffBtn.addEventListener('click', () => showDayPickerModal(plan, todayIdx));

    // Tutorial
    if (!Storage.isTutorialSeen()) {
      setTimeout(() => startTutorial(el), 800);
    }
  }

  function getGreeting() {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  function getNextWorkoutName(plan, todayIdx) {
    for (let i = 1; i <= 7; i++) {
      const d = plan[(todayIdx + i) % 7];
      if (d && !d.isRest) return d.workoutName;
    }
    return 'workout';
  }

  function buildWeekOverview(plan, history) {
    const dayLabels = ['M','T','W','T','F','S','S'];
    const todayIdx = (new Date().getDay() + 6) % 7;
    const todayStr = new Date().toDateString();
    return plan.map((d, i) => {
      const isDone = history.some(h => new Date(h.date).toDateString() === new Date(new Date().setDate(new Date().getDate() - todayIdx + i)).toDateString());
      const cls = isDone ? 'done' : d.isRest ? 'rest' : 'workout';
      const isToday = i === todayIdx;
      return `<div class="week-day-pill ${cls}" style="${isToday ? 'border-color:var(--orange);' : ''}">
        <span style="${isToday ? 'color:var(--text);font-weight:700' : ''}">${dayLabels[i]}</span>
        <span></span>
      </div>`;
    }).join('');
  }

  function showDayPickerModal(plan, todayIdx) {
    const workoutDays = plan.filter(d => !d.isRest);
    if (!workoutDays.length) { App.toast('No workout days set up yet'); return; }
    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.innerHTML = `
      <div class="modal">
        <h3>Pick a Session</h3>
        <p>Today isn't a scheduled workout day. Which session do you want to do?</p>
        <div class="modal-options">
          ${workoutDays.map(d => `
            <div class="modal-option" data-day="${d.day}">
              ${d.emoji} ${d.workoutName}
              <span style="font-size:13px;color:var(--muted);display:block;margin-top:4px">${d.estimatedMin || 30}min · ${d.difficulty || 'Moderate'}</span>
            </div>`).join('')}
        </div>
        <button class="btn btn-secondary btn-full" id="modal-cancel">Cancel</button>
      </div>`;
    modal.querySelector('#modal-cancel').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
    modal.querySelectorAll('.modal-option').forEach(opt => {
      opt.addEventListener('click', () => {
        const dayPlan = workoutDays.find(d => d.day === parseInt(opt.dataset.day));
        modal.remove();
        if (dayPlan) App.startWorkout({ dayPlan });
      });
    });
    document.body.appendChild(modal);
  }

  function startTutorial(el) {
    tutorialStep = 0;
    const overlay = document.getElementById('tutorial-overlay');
    overlay.classList.remove('hidden');
    showTutorialStep();
  }

  function showTutorialStep() {
    const overlay = document.getElementById('tutorial-overlay');
    const tooltip = document.getElementById('tutorial-tooltip');
    const textEl = document.getElementById('tutorial-text');
    const stepInfo = document.getElementById('tutorial-step-info');

    if (tutorialStep >= TUTORIAL_STEPS.length) {
      overlay.classList.add('hidden');
      Storage.markTutorialSeen();
      launchConfetti();
      const user = Storage.getUser() || {};
      App.toast(`You're all set, ${user.name || 'Athlete'}! Let's get to work. 💪`, 'success');
      return;
    }

    const step = TUTORIAL_STEPS[tutorialStep];
    textEl.textContent = step.text;
    stepInfo.textContent = `${tutorialStep + 1} / ${TUTORIAL_STEPS.length}`;

    const target = document.getElementById(step.targetId) || document.querySelector(`[data-tab="${step.targetId.replace('nav-', '')}"]`);
    if (target) {
      const r = target.getBoundingClientRect();
      let spotlight = overlay.querySelector('.tutorial-spotlight');
      if (!spotlight) { spotlight = document.createElement('div'); spotlight.className = 'tutorial-spotlight'; overlay.appendChild(spotlight); }
      spotlight.style.cssText = `top:${r.top - 6}px;left:${r.left - 6}px;width:${r.width + 12}px;height:${r.height + 12}px`;

      const tipY = r.bottom + 12 < window.innerHeight - 120 ? r.bottom + 16 : r.top - 140;
      tooltip.style.cssText = `top:${tipY}px;left:${Math.min(r.left, window.innerWidth - 296)}px`;
    }

    clearTimeout(tutorialTimer);
    tutorialTimer = setTimeout(() => { tutorialStep++; showTutorialStep(); }, 4000);
  }

  document.addEventListener('click', e => {
    if (e.target.id === 'tutorial-next-btn') { clearTimeout(tutorialTimer); tutorialStep++; showTutorialStep(); }
    if (e.target.id === 'tutorial-overlay' && !document.getElementById('tutorial-overlay').classList.contains('hidden')) {
      clearTimeout(tutorialTimer); tutorialStep++; showTutorialStep();
    }
  });

  function launchConfetti() {
    const container = document.getElementById('confetti-container');
    const colors = ['#E8500A', '#C23B22', '#FF6B2B', '#F0F0F0', '#FFB347'];
    for (let i = 0; i < 60; i++) {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';
      piece.style.cssText = `
        left:${Math.random() * 100}%;
        background:${colors[Math.floor(Math.random() * colors.length)]};
        width:${6 + Math.random() * 8}px;height:${6 + Math.random() * 8}px;
        border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
        animation-duration:${1.5 + Math.random() * 2}s;
        animation-delay:${Math.random() * 0.8}s;`;
      container.appendChild(piece);
      setTimeout(() => piece.remove(), 4000);
    }
  }

  return { mount };
})();

window.HomeScreen = HomeScreen;
